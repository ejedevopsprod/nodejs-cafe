<template>
    <div class="hello">
    Hello world
    </div>
</template>

<script>
  export default {
    name: "HelloWorld"
  };
</script>

<style scoped lang="scss">
</style>
